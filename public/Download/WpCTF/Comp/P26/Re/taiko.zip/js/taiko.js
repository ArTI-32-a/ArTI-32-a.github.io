function _0x56be() {
    var _0x270c32 = ['src', '_0x29f89f', 'clearRect', '</td></tr>', 'closeRankButton', 'Big', '三妖精SAY YA!!!', 'Blue', 'roadCtx', 'endmusic', 'getElementById', '_0x39a4c5', '_0x457f1f', '280814gUXlqc', 'endBox', '_0x391803', '_0x39481d', 'startBox', 'fromCharCode', 'event', 'speed', 'username', 'Red', '_0x21a22c', '_0x2ac255', 'push', 'taikoRed', 'kamusic', 'keyCode', '_0x3c2280', 'fillText', '_0x529095', '请输入用户名', 'splice', 'onload', '_0x51d50a', '559431uLVlag', '_0x25beb4', 'parse', 'dongmusic', 'taikoBox', 'backgroundVideo', '_0x401b2d', 'Small', 'judgementText', 'pauseChoice', '<tr><td><div id="firstIcon"></div></td><td>', 'replayButton', 'sort', 'length', 'stringify', 'pause', 'getElementsByClassName', 'bgmusic', 'volume', 'error', '1444508GWKKOW', 'getItem', 'stroke', '<tr><td><div id="firstIcon"></div></td><td>暂无</td><td>暂无</td></tr>', 'color', 'play', 'songSelect', 'catch', 'currentTime', '3iDcAth', 'size', 'onkeydown', '咔~~', 'taikoComb', 'value', 'scoreBoard', 'scoreRank', 'getContext', 'judgementCtx', '330oGGGYd', '15593382YdMyiJ', 'setItem', 'taikoSmile', '_0x1106ac', '_0x5b55e4', '3350697aRBuEB', '咚(大)~', 'onkeyup', '咔(大)~', 'video/song1.mp4', '使用固定间隔: ', 'none', 'beginPath', 'drawImage', 'innerHTML', '20652JbvqhH', '_0x2947dd', 'block', '<tr><td><div id="thirdIcon"></div></td><td>暂无</td><td>暂无</td></tr>', '_0x2ece5a', '_0x4da847', 'style', 'taikoBlue', 'log', 'display', 'duration', '<tr><td><div id="thirdIcon"></div></td><td>', 'fillStyle', 'decode', '视频加载失败:', '2790224JHUrcH', 'utf-8', 'move', 'title_call', 'undefined', '</td><td>'];
    _0x56be = function() {
        return _0x270c32;
    };
    return _0x56be();
}
var _0x3f7b03 = _0x23cd;
(function(_0x553599, _0x56b6a3) {
    var _0x409136 = _0x23cd,
        _0x30c303 = _0x553599();
    while (!![]) {
        try {
            var _0x3a1519 = -parseInt(_0x409136(0x143)) / 0x1 + -parseInt(_0x409136(0x12c)) / 0x2 + -parseInt(_0x409136(0x160)) / 0x3 * (-parseInt(_0x409136(0x157)) / 0x4) + parseInt(_0x409136(0x16a)) / 0x5 * (-parseInt(_0x409136(0x10a)) / 0x6) + -parseInt(_0x409136(0x170)) / 0x7 + -parseInt(_0x409136(0x119)) / 0x8 + parseInt(_0x409136(0x16b)) / 0x9;
            if (_0x3a1519 === _0x56b6a3) break;
            else _0x30c303['push'](_0x30c303['shift']());
        } catch (_0x3c07bf) {
            _0x30c303['push'](_0x30c303['shift']());
        }
    }
}(_0x56be, 0x52d42));
var username, taikoList = [],
    taikoValueList = [],
    taikoValueOrder = 0x0,
    scoreNumber = 0x0,
    perfectCount = 0x0,
    taikoCreat, taikoMove, selectedSong, currentBpm, roadCtx, taikoComb, flag, enc = [0x39,0x53,0xfc,0xcc,0xdf,0xbe,0xad,0xcd,0x1a,0x71,0x05,0x99,0x38,0xdd,0x4f,0x70,0x6d,0x44,0xaa,0x67,0x34,0x26,0x8d,0x06,0xdf,0x37,0x06,0x06,0x76,0x1b,0x45],
    decoyEnc = [0xad,0x04,0xc7,0x33,0x66,0x31,0x34,0xca,0xc6,0x9f,0xab,0xb0,0x7a,0xf9,0xda,0x2a,0x4a,0x67,0x34,0xe9,0x38,0x9c,0x53,0x21,0xa2,0x45,0x9d,0x65,0x1a,0x56,0x83],
    key = [],
    songs = [{
        'name': 'Song1',
        '_0x2ac255': '三妖精SAY YA!!!',
        '_0x51d50a': _0x3f7b03(0x174),
        '_0x3c2280': [],
        '_0x21a22c': 0x96,
        '_0x2b755a': [],
        'duration': 0x25d78,
        '_0x5b55e4': 0x64
    }];
window[_0x3f7b03(0x141)] = function() {
    var _0x500160 = _0x3f7b03;
    const _0x3ab992 = 0.4;
    document[_0x500160(0x129)]('bgmusic')[_0x500160(0x155)] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x11c))[_0x500160(0x155)] = _0x3ab992, document[_0x500160(0x129)]('gamestart')[_0x500160(0x155)] = _0x3ab992, document['getElementById'](_0x500160(0x146))['volume'] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x13a))['volume'] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x128))[_0x500160(0x155)] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x125))[_0x500160(0x155)] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x148))[_0x500160(0x155)] = _0x3ab992, document[_0x500160(0x129)](_0x500160(0x154))['play'](), setTimeout(function() {
        var _0xf44068 = _0x500160;
        document['getElementById'](_0xf44068(0x11c))['play']();
    }, 0x1f4);
    _0x41e7(function(_0x4d9b) { songs[0x0]['_0x3c2280'] = _0x4d9b; });
};

function gameStart() {
    var _0x33736e = _0x3f7b03;
    username = document[_0x33736e(0x129)](_0x33736e(0x134))[_0x33736e(0x165)];
    var _0x48c152 = document['getElementById'](_0x33736e(0x15d))[_0x33736e(0x165)];
    selectedSong = songs[_0x48c152], username == '' ? document[_0x33736e(0x129)](_0x33736e(0x130))['getElementsByTagName']('h4')[0x0][_0x33736e(0x109)] = _0x33736e(0x13f) : (document[_0x33736e(0x129)](_0x33736e(0x130))['style']['display'] = _0x33736e(0x106), document['getElementById']('ruleBox')[_0x33736e(0x110)][_0x33736e(0x113)] = _0x33736e(0x10c));
}

function gamePlay() {
    var _0x111afd = _0x3f7b03;
    document[_0x111afd(0x129)]('ruleBox')[_0x111afd(0x110)][_0x111afd(0x113)] = 'none', document[_0x111afd(0x129)](_0x111afd(0x130))[_0x111afd(0x110)][_0x111afd(0x113)] = _0x111afd(0x106), document[_0x111afd(0x129)](_0x111afd(0x12d))[_0x111afd(0x110)][_0x111afd(0x113)] = 'none', document[_0x111afd(0x129)](_0x111afd(0x147))[_0x111afd(0x110)]['display'] = _0x111afd(0x10c), taikoList = [], taikoValueOrder = 0x0, clearInterval(taikoCreat), clearInterval(taikoMove), scoreNumber = 0x0, document[_0x111afd(0x129)](_0x111afd(0x166))['innerHTML'] = scoreNumber, document[_0x111afd(0x129)](_0x111afd(0x14c))['style'][_0x111afd(0x113)] = _0x111afd(0x106), document[_0x111afd(0x129)](_0x111afd(0x154))[_0x111afd(0x152)](), document['getElementById']('endmusic')[_0x111afd(0x152)](), document['getElementById']('gamestart')[_0x111afd(0x15c)]();
    var _0x2aeb46 = document['getElementById'](selectedSong[_0x111afd(0x137)]),
        _0x5b08f1 = document[_0x111afd(0x129)](_0x111afd(0x148));
    setTimeout(function() {
        var _0x70c625 = _0x111afd;
        _0x2aeb46[_0x70c625(0x15f)] = 0x0, _0x2aeb46[_0x70c625(0x15c)]()['catch'](function(_0x210fce) {
            console['error']('音频加载失败:', _0x210fce);
        }), _0x5b08f1[_0x70c625(0x11f)] = selectedSong[_0x70c625(0x142)], _0x5b08f1[_0x70c625(0x15f)] = 0x0, _0x5b08f1['play']()[_0x70c625(0x15e)](function(_0x1d299a) {
            var _0x577056 = _0x70c625;
            console[_0x577056(0x156)](_0x577056(0x118), _0x1d299a);
        });
    }, 0x7d0), taikoValueList = selectedSong[_0x111afd(0x13c)], currentBpm = selectedSong[_0x111afd(0x136)];
    var _0x266f6d;
    selectedSong[_0x111afd(0x16f)] ? (_0x266f6d = selectedSong[_0x111afd(0x16f)], console[_0x111afd(0x112)](_0x111afd(0x105) + _0x266f6d + 'ms')) : _0x266f6d = 0xea60 / currentBpm, roadCtx = document[_0x111afd(0x129)](_0x111afd(0x127))['getContext']('2d'), taikoComb = document['getElementById'](_0x111afd(0x164)), setTimeout(function() {
        taikoCreat = setInterval(function() {
            creatTaiko(roadCtx, taikoComb);
        }, _0x266f6d), taikoMove = setInterval(function() {
            taikoListMove(roadCtx);
        }, 0x1);
    }, 0x302), setTimeout(function() {
        gameEnd(), saveScore();
    }, selectedSong[_0x111afd(0x114)]);
}

function gamePause() {
    var _0x26d471 = _0x3f7b03;
    clearInterval(taikoCreat), clearInterval(taikoMove), document[_0x26d471(0x129)](selectedSong['_0x2ac255'])[_0x26d471(0x152)](), document[_0x26d471(0x129)](_0x26d471(0x148))[_0x26d471(0x152)](), document['getElementById'](_0x26d471(0x14c))[_0x26d471(0x110)][_0x26d471(0x113)] = _0x26d471(0x10c);
}

function gameContinue() {
    var _0x511bf8 = _0x3f7b03;
    document[_0x511bf8(0x129)](_0x511bf8(0x14c))[_0x511bf8(0x110)][_0x511bf8(0x113)] = _0x511bf8(0x106);
    var _0x63a956;
    selectedSong[_0x511bf8(0x16f)] ? _0x63a956 = selectedSong[_0x511bf8(0x16f)] : _0x63a956 = 0xea60 / currentBpm, taikoCreat = setInterval(function() {
        creatTaiko(roadCtx, taikoComb);
    }, _0x63a956), taikoMove = setInterval(function() {
        taikoListMove(roadCtx);
    }, 0x1), document[_0x511bf8(0x129)](selectedSong[_0x511bf8(0x137)])[_0x511bf8(0x15c)](), document[_0x511bf8(0x129)](_0x511bf8(0x148))[_0x511bf8(0x15c)]();
}
window[_0x3f7b03(0x162)] = function() {
    var _0x5e6922 = _0x3f7b03,
        _0x3b1487 = document[_0x5e6922(0x153)]('taikoRed'),
        _0x1412c0 = document['getElementsByClassName']('taikoBlue'),
        _0x1dd28e = document['getElementById'](_0x5e6922(0x146)),
        _0x271773 = document[_0x5e6922(0x129)]('kamusic'),
        _0x560e09 = window['event'] || arguments[0x0];
    _0x560e09[_0x5e6922(0x13b)] == 0x43 && (imgDisplay(_0x1412c0[0x0]), _0x271773[_0x5e6922(0x15f)] = 0x0, _0x271773[_0x5e6922(0x15c)](), taikoCheck(_0x5e6922(0x126))), _0x560e09[_0x5e6922(0x13b)] == 0x56 && (imgDisplay(_0x3b1487[0x0]), _0x1dd28e[_0x5e6922(0x15f)] = 0x0, _0x1dd28e[_0x5e6922(0x15c)](), taikoCheck(_0x5e6922(0x135))), _0x560e09['keyCode'] == 0x42 && (imgDisplay(_0x3b1487[0x1]), _0x1dd28e[_0x5e6922(0x15f)] = 0x0, _0x1dd28e[_0x5e6922(0x15c)](), taikoCheck(_0x5e6922(0x135))), _0x560e09[_0x5e6922(0x13b)] == 0x4e && (imgDisplay(_0x1412c0[0x1]), _0x271773[_0x5e6922(0x15f)] = 0x0, _0x271773[_0x5e6922(0x15c)](), taikoCheck(_0x5e6922(0x126)));
}, window[_0x3f7b03(0x172)] = function() {
    var _0x25c675 = _0x3f7b03,
        _0x25d84b = document[_0x25c675(0x153)](_0x25c675(0x139)),
        _0x16cb88 = document['getElementsByClassName'](_0x25c675(0x111)),
        _0x300876 = window[_0x25c675(0x132)] || arguments[0x0];
    _0x300876[_0x25c675(0x13b)] == 0x43 && imgDisAppear(_0x16cb88[0x0]), _0x300876['keyCode'] == 0x56 && imgDisAppear(_0x25d84b[0x0]), _0x300876[_0x25c675(0x13b)] == 0x42 && imgDisAppear(_0x25d84b[0x1]), _0x300876[_0x25c675(0x13b)] == 0x4e && imgDisAppear(_0x16cb88[0x1]);
};

function creatTaiko(_0x14107f, _0x2dfefc) {
    var _0x361e8f = _0x3f7b03;
    checkBpmChange();
    if (taikoValueOrder >= taikoValueList[_0x361e8f(0x150)]) return;
    var _0x4ae4ee;
    if (taikoValueList[taikoValueOrder] == 0x0) {
        taikoValueOrder++;
        return;
    }
    taikoValueList[taikoValueOrder] == 0x1 && (_0x4ae4ee = new taikoPrototype(_0x14107f, _0x2dfefc, 0x1, 0x12, '咚~~'));
    taikoValueList[taikoValueOrder] == 0x2 && (_0x4ae4ee = new taikoPrototype(_0x14107f, _0x2dfefc, 0x2, 0x12, _0x361e8f(0x163)));
    taikoValueList[taikoValueOrder] == 0x3 && (_0x4ae4ee = new taikoPrototype(_0x14107f, _0x2dfefc, 0x3, 0x8, _0x361e8f(0x171)));
    taikoValueList[taikoValueOrder] == 0x4 && (_0x4ae4ee = new taikoPrototype(_0x14107f, _0x2dfefc, 0x4, 0x8, _0x361e8f(0x173)));
    if (!_0x4ae4ee) {
        taikoValueOrder++;
        return;
    }
    taikoList['push'](_0x4ae4ee), taikoValueOrder++;
}

function checkBpmChange() {
    var _0x17015f = _0x3f7b03,
        _0x2caa2d = selectedSong['_0x2b755a'] || [];
    for (var _0x1cfb16 = 0x0; _0x1cfb16 < _0x2caa2d['length']; _0x1cfb16++) {
        if (_0x2caa2d[_0x1cfb16][_0x17015f(0x120)] === taikoValueOrder) {
            var _0x4a7aff = currentBpm;
            currentBpm = _0x2caa2d[_0x1cfb16][_0x17015f(0x12e)], clearInterval(taikoCreat), taikoCreat = setInterval(function() {
                creatTaiko(roadCtx, taikoComb);
            }, 0xea60 / currentBpm);
            var _0x3da654 = currentBpm / _0x4a7aff;
            for (var _0x5ea0c4 = 0x0; _0x5ea0c4 < taikoList['length']; _0x5ea0c4++) {
                taikoList[_0x5ea0c4][_0x17015f(0x133)] *= _0x3da654;
            }
            _0x2caa2d[_0x17015f(0x140)](_0x1cfb16, 0x1);
            break;
        }
    }
}

function taikoPrototype(_0x5727ce, _0xd2dc24, _0x488b89, _0x5e4615, _0x116e33) {
    var _0x4eb0c9 = _0x3f7b03;
    switch (_0x488b89) {
        case 0x1:
            this[_0x4eb0c9(0x15b)] = _0x4eb0c9(0x135), this[_0x4eb0c9(0x161)] = _0x4eb0c9(0x14a), this['_0x4da847'] = 0x32;
            break;
        case 0x2:
            this['color'] = _0x4eb0c9(0x126), this['size'] = _0x4eb0c9(0x14a), this['_0x4da847'] = 0x32;
            break;
        case 0x3:
            this[_0x4eb0c9(0x15b)] = _0x4eb0c9(0x135), this['size'] = 'Big', this[_0x4eb0c9(0x10f)] = 0x46;
            break;
        case 0x4:
            this[_0x4eb0c9(0x15b)] = _0x4eb0c9(0x126), this[_0x4eb0c9(0x161)] = _0x4eb0c9(0x124), this[_0x4eb0c9(0x10f)] = 0x46;
            break;
    }
    this['_0x2ece5a'] = _0x5727ce, this[_0x4eb0c9(0x13e)] = _0xd2dc24, this['_0x1106ac'] = (_0x488b89 - 0x1) * 0xfa, this[_0x4eb0c9(0x12a)] = 0x0, this['_0x25beb4'] = 0xfa, this[_0x4eb0c9(0x149)] = 0x285, this[_0x4eb0c9(0x12b)] = _0x5e4615, this[_0x4eb0c9(0x133)] = 0x2 * (currentBpm / 0x96), this[_0x4eb0c9(0x10b)] = function() {
        var _0x591c60 = _0x4eb0c9;
        this[_0x591c60(0x10e)][_0x591c60(0x107)](), this['_0x2ece5a']['drawImage'](this[_0x591c60(0x13e)], this[_0x591c60(0x16e)], this[_0x591c60(0x12a)], this[_0x591c60(0x144)], this[_0x591c60(0x144)], this[_0x591c60(0x149)], this[_0x591c60(0x12b)], this[_0x591c60(0x10f)], this[_0x591c60(0x10f)]), this[_0x591c60(0x10e)]['stroke'](), this['_0x2ece5a'][_0x591c60(0x116)] = 'black', this[_0x591c60(0x10e)]['font'] = '16px 微软雅黑', this[_0x591c60(0x10e)][_0x591c60(0x13d)](_0x116e33, this['_0x401b2d'] + this[_0x591c60(0x10f)] / 0x2 - 0x12, 0x71);
    }, this[_0x4eb0c9(0x11b)] = function() {
        var _0x7aafe3 = _0x4eb0c9;
        this[_0x7aafe3(0x149)] -= this[_0x7aafe3(0x133)];
    };
}

function _0x23cd(_0x4e3418, _0x19ecd5) {
    var _0x56be36 = _0x56be();
    return _0x23cd = function(_0x23cd24, _0x7a01bf) {
        _0x23cd24 = _0x23cd24 - 0x105;
        var _0x3f7645 = _0x56be36[_0x23cd24];
        return _0x3f7645;
    }, _0x23cd(_0x4e3418, _0x19ecd5);
}

function taikoListMove(_0x166966) {
    var _0x520a6c = _0x3f7b03;
    _0x166966[_0x520a6c(0x121)](0x0, 0x0, 0x285, 0x78);
    for (var _0xb5a21 = taikoList[_0x520a6c(0x150)] - 0x1; _0xb5a21 >= 0x0; _0xb5a21--) {
        taikoList[_0xb5a21][_0x520a6c(0x149)] > -taikoList[_0xb5a21][_0x520a6c(0x10f)] ? (taikoList[_0xb5a21][_0x520a6c(0x10b)](), taikoList[_0xb5a21][_0x520a6c(0x11b)]()) : taikoList[_0x520a6c(0x140)](_0xb5a21, 0x1);
    }
}

function taikoCheck(_0x55a9b6) {
    var _0x3b66a7 = _0x3f7b03,
        _0x4eb9ff = ![],
        _0x14a062 = document[_0x3b66a7(0x129)](_0x3b66a7(0x166)),
        _0xcd57c7 = document[_0x3b66a7(0x129)](_0x3b66a7(0x16d)),
        _0x5a7631;
    for (var _0x172cc4 = 0x0; _0x172cc4 < taikoList[_0x3b66a7(0x150)]; _0x172cc4++) {
        taikoList[_0x172cc4][_0x3b66a7(0x161)] == _0x3b66a7(0x14a) ? _0x5a7631 = 0x16 : _0x5a7631 = 0xc, taikoList[_0x172cc4][_0x3b66a7(0x149)] > _0x5a7631 - 0x32 && taikoList[_0x172cc4][_0x3b66a7(0x149)] < _0x5a7631 + 0x32 && taikoList[_0x172cc4][_0x3b66a7(0x15b)] == _0x55a9b6 && (_0x4eb9ff = !![], _0xcd57c7['style'][_0x3b66a7(0x113)] = _0x3b66a7(0x10c), setTimeout(function() {
            var _0x4c159f = _0x3b66a7;
            _0xcd57c7[_0x4c159f(0x110)][_0x4c159f(0x113)] = _0x4c159f(0x106);
        }, 0x64), taikoList[_0x172cc4][_0x3b66a7(0x149)] > _0x5a7631 - 0x1e && taikoList[_0x172cc4][_0x3b66a7(0x149)] < _0x5a7631 + 0x1e ? (judgement(0x0), perfectCount++, scoreNumber += 0x64) : (judgement(0x1), scoreNumber += 0x32), taikoList[_0x3b66a7(0x140)](_0x172cc4, 0x1), _0x14a062[_0x3b66a7(0x109)] = scoreNumber);
    }
    if (_0x4eb9ff == ![]) {
        var _0x2c747f = document['getElementById'](_0x3b66a7(0x169))[_0x3b66a7(0x168)]('2d'),
            _0x20389f = document[_0x3b66a7(0x129)](_0x3b66a7(0x14b));
        _0x2c747f['beginPath'](), _0x2c747f['drawImage'](_0x20389f, 0x0, 0x32, 0x3f, 0x19, 0xc, 0x64, 0x4c, 0x1e), _0x2c747f[_0x3b66a7(0x159)](), setTimeout(function() {
            var _0x28adc4 = _0x3b66a7;
            _0x2c747f[_0x28adc4(0x121)](0x0, 0x0, 0x28a, 0xfa);
        }, 0xc8), scoreNumber -= 0x1f4, scoreNumber < 0x0 && (scoreNumber = 0x0), _0x14a062[_0x3b66a7(0x109)] = scoreNumber;
    }
}

function judgement(_0x54890f) {
    var _0x205b07 = _0x3f7b03,
        _0x50b37f = 0x0,
        _0x41b6fe = document[_0x205b07(0x129)](_0x205b07(0x169))[_0x205b07(0x168)]('2d'),
        _0x5ba010 = document[_0x205b07(0x129)](_0x205b07(0x14b)),
        _0x3c9f66 = document['getElementById']('judgementHalo');
    _0x500fb9();

    function _0x500fb9() {
        var _0x3e185b = _0x205b07;
        _0x41b6fe[_0x3e185b(0x121)](0x0, 0x0, 0x28a, 0xfa), _0x41b6fe[_0x3e185b(0x107)](), _0x41b6fe[_0x3e185b(0x108)](_0x3c9f66, _0x50b37f * 0x8c, _0x54890f * 0x8c, 0x8c, 0x8c, -0x13, 0x5d, 0x8c, 0x8c), _0x41b6fe[_0x3e185b(0x159)](), _0x41b6fe[_0x3e185b(0x107)](), _0x41b6fe[_0x3e185b(0x108)](_0x5ba010, 0x0, _0x54890f * 0x19, 0x3f, 0x19, 0xc, 0x64, 0x4c, 0x1e), _0x41b6fe[_0x3e185b(0x159)](), _0x50b37f++, _0x50b37f < 0x4 && setTimeout(_0x500fb9, 0x64), _0x50b37f == 0x4 && _0x41b6fe[_0x3e185b(0x121)](0x0, 0x0, 0x28a, 0xfa);
    }
}

function imgDisplay(_0x51f1e8) {
    var _0x7dc650 = _0x3f7b03;
    _0x51f1e8[_0x7dc650(0x110)][_0x7dc650(0x113)] = _0x7dc650(0x10c);
}

function imgDisAppear(_0x22b31c) {
    var _0x196cc0 = _0x3f7b03;
    _0x22b31c[_0x196cc0(0x110)]['display'] = _0x196cc0(0x106);
}

function gameEnd() {
    var _0x4c8c6c = _0x3f7b03;
    clearInterval(taikoCreat), clearInterval(taikoMove), taikoList = [];
    var _0x5e6633 = document[_0x4c8c6c(0x129)](selectedSong[_0x4c8c6c(0x137)]);
    _0x5e6633 && (_0x5e6633['pause'](), _0x5e6633[_0x4c8c6c(0x15f)] = 0x0);
    var _0xb483d5 = document[_0x4c8c6c(0x129)](_0x4c8c6c(0x148));
    _0xb483d5 && (_0xb483d5['pause'](), _0xb483d5[_0x4c8c6c(0x15f)] = 0x0);
    saveScore();
    if (scoreNumber == computeTargetScore()) {
        var _0x2e8f48 = arrayToString(decodeFlag(restoreEnc(), deriveKey()));
        alert(_0x2e8f48), document['getElementById']('taikoBox')['style'][_0x4c8c6c(0x113)] = _0x4c8c6c(0x106), document[_0x4c8c6c(0x129)](_0x4c8c6c(0x12d))[_0x4c8c6c(0x110)]['display'] = _0x4c8c6c(0x10c), document[_0x4c8c6c(0x129)](_0x4c8c6c(0x14e))[_0x4c8c6c(0x110)]['display'] = _0x4c8c6c(0x10c), document[_0x4c8c6c(0x129)](_0x4c8c6c(0x123))[_0x4c8c6c(0x110)][_0x4c8c6c(0x113)] = _0x4c8c6c(0x10c), queryScore();
    } else document[_0x4c8c6c(0x129)](_0x4c8c6c(0x128))[_0x4c8c6c(0x15c)](), taikoList = [], taikoValueOrder = 0x0, scoreNumber = 0x0, document[_0x4c8c6c(0x129)](_0x4c8c6c(0x166))[_0x4c8c6c(0x109)] = scoreNumber, document[_0x4c8c6c(0x129)]('taikoBox')[_0x4c8c6c(0x110)][_0x4c8c6c(0x113)] = _0x4c8c6c(0x106), document['getElementById'](_0x4c8c6c(0x130))[_0x4c8c6c(0x110)][_0x4c8c6c(0x113)] = _0x4c8c6c(0x10c);
}

function saveScore() {
    var _0x5a2757 = _0x3f7b03;
    let _0x20271b = JSON[_0x5a2757(0x145)](localStorage[_0x5a2757(0x158)]('scoreRank')) || [];
    _0x20271b[_0x5a2757(0x138)]({
        'username': username,
        '_0x39481d': parseInt(scoreNumber)
    }), _0x20271b[_0x5a2757(0x14f)]((_0xe30c9f, _0x3740e1) => _0x3740e1['_0x39481d'] - _0xe30c9f[_0x5a2757(0x12f)]), _0x20271b['length'] > 0xa && (_0x20271b = _0x20271b['slice'](0x0, 0xa)), localStorage[_0x5a2757(0x16c)](_0x5a2757(0x167), JSON[_0x5a2757(0x151)](_0x20271b));
}

function queryScore() {
    var _0x38f733 = _0x3f7b03;
    let _0x13f009 = JSON[_0x38f733(0x145)](localStorage['getItem'](_0x38f733(0x167))) || [];
    _0x13f009[_0x38f733(0x14f)]((_0x322813, _0x3298ed) => _0x3298ed['_0x39481d'] - _0x322813['_0x39481d']);
    let _0x39f8f8 = '';
    _0x13f009[_0x38f733(0x150)] >= 0x1 ? _0x39f8f8 += _0x38f733(0x14d) + _0x13f009[0x0][_0x38f733(0x134)] + _0x38f733(0x11e) + _0x13f009[0x0][_0x38f733(0x12f)] + _0x38f733(0x122) : _0x39f8f8 += _0x38f733(0x15a), _0x13f009[_0x38f733(0x150)] >= 0x2 ? _0x39f8f8 += '<tr><td><div id="secondIcon"></div></td><td>' + _0x13f009[0x1][_0x38f733(0x134)] + _0x38f733(0x11e) + _0x13f009[0x1]['_0x39481d'] + _0x38f733(0x122) : _0x39f8f8 += '<tr><td><div id="secondIcon"></div></td><td>暂无</td><td>暂无</td></tr>', _0x13f009['length'] >= 0x3 ? _0x39f8f8 += _0x38f733(0x115) + _0x13f009[0x2][_0x38f733(0x134)] + _0x38f733(0x11e) + _0x13f009[0x2][_0x38f733(0x12f)] + _0x38f733(0x122) : _0x39f8f8 += _0x38f733(0x10d), document['getElementById'](_0x38f733(0x167))['innerHTML'] = _0x39f8f8;
}

function viewRank() {
    var _0x2bf256 = _0x3f7b03;
    document[_0x2bf256(0x129)](_0x2bf256(0x130))['style'][_0x2bf256(0x113)] = _0x2bf256(0x106), document[_0x2bf256(0x129)](_0x2bf256(0x12d))[_0x2bf256(0x110)][_0x2bf256(0x113)] = _0x2bf256(0x10c), document[_0x2bf256(0x129)](_0x2bf256(0x14e))['style'][_0x2bf256(0x113)] = _0x2bf256(0x106), document['getElementById'](_0x2bf256(0x123))[_0x2bf256(0x110)]['display'] = _0x2bf256(0x10c), queryScore();
}

function closeRank() {
    var _0x4368bc = _0x3f7b03;
    document[_0x4368bc(0x129)](_0x4368bc(0x12d))[_0x4368bc(0x110)][_0x4368bc(0x113)] = _0x4368bc(0x106), document['getElementById'](_0x4368bc(0x130))[_0x4368bc(0x110)][_0x4368bc(0x113)] = _0x4368bc(0x10c);
}

function returnToMenu() {
    var _0x316e3c = _0x3f7b03;
    clearInterval(taikoCreat), clearInterval(taikoMove);
    var _0x1a1415 = document[_0x316e3c(0x129)](selectedSong ? selectedSong[_0x316e3c(0x137)] : _0x316e3c(0x125));
    _0x1a1415 && (_0x1a1415[_0x316e3c(0x152)](), _0x1a1415['currentTime'] = 0x0);
    var _0x3a8d1f = document[_0x316e3c(0x129)](_0x316e3c(0x148));
    _0x3a8d1f && (_0x3a8d1f[_0x316e3c(0x152)](), _0x3a8d1f['currentTime'] = 0x0), taikoList = [], taikoValueOrder = 0x0, scoreNumber = 0x0, document[_0x316e3c(0x129)]('scoreBoard')[_0x316e3c(0x109)] = scoreNumber, document[_0x316e3c(0x129)](_0x316e3c(0x147))[_0x316e3c(0x110)][_0x316e3c(0x113)] = _0x316e3c(0x106), document[_0x316e3c(0x129)](_0x316e3c(0x130))[_0x316e3c(0x110)][_0x316e3c(0x113)] = _0x316e3c(0x10c), document[_0x316e3c(0x129)](_0x316e3c(0x154))['play']();
}


var _0x41e7D = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABbgAAANgCAIAAABhg5kNAAApNElEQVR42u3dUXLquBYFUEZDZTQZPgNI5TtTyLtFNqnuGx7twEE+ltcqPnWNfCzL8o66OXwCAAAAcHZQAgAAAIAvghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAIjDBwAAAABnghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUALABrwfj/qjP5voT7dzZ75xaIwZP8YPPJugBIDW68KfH/3Rn4b96XbuzDePGWPGj/EDwxyu3kWtuvjy+jblcbrVR38Y8KQ3J7h3Hl/Vrbi20x/96XbuVffpkn5Wtak6ryVtOjx3qsbGM8ZYVZ2rvmvkjoklbWZ6Dq41fsw/+5zn52hzuHELdVim//MzzXG61Ud/GPyYNye4d7x464+gpMl9uqS3VW2qzmtJmz7PnZ4vulV1rvququtVNVbnew6OHz/mnz7r3pF1nqmNoMTLjP4gKDG3CEr0R38EJV5UBCWCEkGJ+UdQos0lKDldXL1zTuv5a2R8fSY4Trf66A/PVjW3zDonuHd+NXJWfELpj/70Ofeq+3RJb6vaVJ3XkjZ9njtVY6N2jFXVueq7qq5X1Vid7zk4fvyYf/qse0fWebI2dpT4q6/+YEeJucWOEv3RHztK/EXXjhI7SuwoMf/YUaLNZUeJoMTLjP4gKDG3CEr0R38EJV5UBCWCEkGJ+UdQos2VoOS7aatXLL9MoT8z9WfncYk5wb3jxVt/BCUN71O/OvG8OvvVm/HXy6/e9Bk/5p99zvMT/uoNALTS561bf/RnW+fOfPOYMWb8GD8wjKAEgG2sFPVHfzbRH+8ePHtsGGPGj/EDzyYoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAAHH4BAAAAOBMUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIA4fAAAAAJwJSgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQDAUO/HoyIAQNvnqaAEAGDQeu7nR1kAoNvz9HD1W5f0rOTrX17fulV82HG2WOeR/VnSZov1WdJGf/TH/LNuf2atT9Xcqz+Fq7omWYn5R39mWodv8bk8Urd11Mj6zLqu29v715jn6eHGVy7p1iOl+eenw9Rccl5VNexW55H9WdJmi/VZ0kZ/9Mf8s25/Zq1P1dyrP4/0p2dQYv7pM/9ssT/dxuEWn8uDI5JW66iR9Zl1XbfP9y9BiYWCoERQoj/6Y/4RlAgmBCXWP4IJ63BBiaBEUOL9a2xQcrq4+k2nf1vSZom/qvP1Oa2n6ryqatitziP7s6TNFuuzpI3+6I/5Z935Z9b6VM29+vNIf26s6u4eRdY/M80/W+xPt3G4xefySN3WUSPrM+u6bp/vX8Oep3aU+IuKRNOOCf2xo8T8Y0eJ/thRYv7RHztK7Cixo8SOEjtKLjtKBCUWCm5UQYD+CErMP4IS/RGUmH/0R1AiKBGUCEoEJVeCku8vXtK5qtv1oxP/1/c+/fGrN/qjP+aftfrjV2/05xn98as35h+/erPPOvvVmz718as3c7x/rRaUAADwjDV6w5QEADxP/yIoAQAYvcJTBABo+zwVlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIA4fAIAAABwJigBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCHDwAAAADOBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAADEnUHJy+tbq9N4Px5b9adbfQBgi7o93wGAPfhdUPLn/f/nZ93108/Piv3pVh8A2KJuz3cAYFd+EZRcTQFWzAKurqJWXEt1q89ftRp2nKo2C2veqj6z9qfbOOxW51l3tHW736v6XFWfJcdZ0qbbOBxZn6083xl/X2zx/ho5/3SbN7ZYn5HPL+NnzL3s/nJ/1dZHUDJ5UFJVmSXHqWpzR7VXr8+s/ek2DrvVudsr3Mj6jLzfq/pcVZ8lx1nSpts4HFkfQcmUEUnJfbHF+2vk/NNt3thifUY+v4yfx+cN95f7a636CEoEJYIS/RGUCEoEJYISQQmCEi+6XuTUR1Di/nJ/XYKS0zI3UoCvz2msG6uor8/g/nSrz40qPek4VW3urvaK9Zm1P93GYbc6d5h51qrPyPu9qs9V9VlynCVtuo3DkfXZ1vOdkffFFu+vkfNPt3lji/UZ+fwyfh6fN9xf7q8V62NHiR0ldpTojx0ldpTYUWJHiR0l2FFiR4C/eKuPHSXuL/fXZUeJoERQIijRH0GJoERQIigRlCAo8aLrRU59BCXuL/eXoGQXQcl3rYYdx6/ezNefbuPQr970qY9fvXm8jV+9EZRMFpe0auNXS9Snw/PL+BlzL7u/3F+19Tn8dhx33i6x+iqqZ0oCANsiJQEAVnS475/N+pfqKvIRAJjv+Q4A7MFBCQAAAAC+CEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAACIwycAAAAAZ4ISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAABx+AAAAADgTFACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABArByUvB+Prcrx8vrW6jjqs636wEzcX+qjPuqzdd3WLcB+5g22bp2g5M/64Odn3fvh52fF46jPtuoDk72/ub/UR33UZ+vvOa3WLcB+5g32HpQ88ly/ukpYca1w9a64496oOo769KzPkuOP/MvVkjZVNem2A2iL9dnK9eo2/zxpTpuyPh3+cq4+4+uz5N+OfH5V9eeRmnRbt6y1JtmibuuWque7Hdn9+9P5fp/1Pu1/Xoc7DvHgo10QoD7bqs+Sb6maUpccZ0mbqspUndfI/nSrz7au19xByaz1GTn/qE+f+iw5wsjnV1V/Hq/M3EHJrBF2t3VL1fO9z/zTc/w03z4vKNn5/CMoEQSoj6BEUOJ6CUoEAeojKBGUCEoEJYISQYmgxPxzCUpOv3H16f74Ee4+2uNu3BVfn8HHUZ9u9VnyLY+c0W+Ps6RNVWWqzmtkf7rVZ1vXq9v8M2A2m6A+I+cf9elTnyVHGPn8qurP45Xptm4ZvybZom7rlqrne5/5p+f4af6kWP1+n/U+3dB52VFix4T62FFiR4nrZUeJHRPqY0eJHSV2lNhRYkeJHSV2lJh/LjtKBCWCAPURlAhKXC9BiSBAfQQlghJBiaBEUCIoEZSYf+4MSr4PV9UVQYD6bKI+fvVmTA1nrY9fvWkVl0xZH796s8/6+NWbvQUltc+Lhq8rm7vf/erNHP0RlJh/Cn715hmxTc8QccXjqM+26gOTPSfcX+qjPuqzad3WLcB+5g2mcVj367utDyS+6gO4v9RHfdRnmjefVscB9jNvsHUHJQAAAAD4IigBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgDp8AAAAAnAlKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAADE4QMAAACAM0EJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISiBj5fXN0UA+OP9eFQEPE8B2DlBCbtez/38KAuwQ+/H48+PsuB5CsA+3RmUdHv+VfWn6jhV68sl/alqs8X6lK/qmqztquqz5DhVbWa9v/bcn6qxMfK8Ro7nbtf9wXP5fx/rpOY6jOfOz1PM8xirz3hvGjlWtVmrza+Dkm6PwKr+VB2naom5pD9VbbZYn1mDkqr6LDlOVZtZ768996dqbIw8r5Hjudt1F5Ts9rWhyXgWlMw6fvY8z7PPsbqkzcixqs26bQQlghJBiaBEUKI/FtCCEkGJoERQYvyY5xGUCEq0uQQlp9+4+hQ8raeqP1XHubrKfFJ/qtpssT5PGjmrj+qq+iw5TlWbWe+vPfenamyMPK+R47nbdX/SzLP6LE2f+32Lz1PM82YwY/UZ700jx6o2q7exo8SOEjtK7Cixo0R//KXRjhI7SuwosaPE+DHPY0eJHSXaXHaUCEoEJYISQYmgRH8soAUlghJBiaDE+DHPIygRlGhzZ1DyPYxa3UJ+9Waf9ZkvKKmtj1+90Z8O48ev3vR/ngpKNv0KsfpxBCVzjx+/esPexqpfvdHmoaAEJmBVB/C9PpCS4HkKAF8EJfBhPQfwRT6C5ykACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABAHD4BAAAAOBOUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAACIwwcAAAAAZ4ISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACu/by+qYIAMAm1hvvx6NiAgMISmCn65WfH2UBABquN96Px58f5QWe53B1JloyW2mjzeptKFy1NMlKul33qv50+0vakv4saaM+8/Wn6rtGXq9uz52q76qqs/tLfdaqc9V642pK8mBWssV5w/rH/KM+I+fDw41paMlUpY02q7RhvqCk23Wv6k9VhUf2Z0kb9elTn6r+VH3XyOvV7blT9V1VdXZ/qc8jY+zx8+oZlGxx3rD+Mf+oz/j5UFCijaBEUCIo8SC0ULBQEJQIStxfghJBiaDE/WX+sf65BCWni6uzz+nftNGmQxsecWPV8vVZpVfdrntVf6oqPLI/S9qoT5/6VPWn6rtGXq9uz52q76qqs/tLfR4ZY4+fV9V640ZKckevtjhvWP+Yf9RnlfnQjhJt7Cixo8SOEn8x8BcVf1Gxo8SOEveXHSV2lNhR4v4y/1j/XHaUePHWRlAiKBGUeBBaKFgoCEoEJe4vQYmgRFDi/jL/WP9cCUq+D7fkkmijzeptmCko6Xnd/V/N1Wcr9fGrN32eO371xvwz0/3uV2/6zBvWP+Yf9Rk5Hx68NIKspElKAgBYb1x9zylMSQD+k6AE9r6CUQQAYBPrDfkIMIagBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAMThEwAAAIAzQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgDh8AAAAAHAmKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAA/If347HVcZzXPs9rz15e3xQBhhGUAADwf9+Tf35WPI7z2ud57dnL69vPj7LAsx2u3o1VM/Ww41S1Gfwka/Vd3a57VX+WHGdJm27jZ+QzcmR9uo2fLd7v3eq85/Ez67w6a39mHT/lb913vDNXHcd57fO8Oj8rn/0OcjUlaZKVdHvX2/Oze+Raa2R91n2HPdy4Faum6acep6rNio+x1b+r23Wv6s+S4yxp0238jHxMjqxPt/Gzxfu9W533PH5mnVdn7c+s48eLt/MSlGz9HaRnUNLtXW/Pz+6Ra62R9enwDisoEZQISgQlghJBiaDEYktQIigRKDgvQYmgRFAiKBGUXIKS08XVO/D0e1dn1Scdp6rNSCP7s+S7ul33qv4sOc6SNt3GT1V9qr5r5P3erT7d7vdudd7z+Jl1Xp21P7OOnyfNGHdUqeo4zmuf59XzWTnmHeRGStJtZlixznt+do9ca42sT5N3WDtK7Cixo8SOEjtK7Cixo8RfpewosaPEzgvnZUeJHSV2lNhRYkfJZUeJoERQIigRlAhKBCWCEostQYmgRKDgvAQlghJBiaBEUHIlKPn+yqpbaNhx/OrN49/lV2+2NX786k2f+nS737vV2a/ezHdefvVmW+PHi7fzEpRs9x3Er96Mf5fxqzd96tPoV28AAOD2O/OKx3Fe+zyvPeuZksD0BCUAAPz3m3Or4zivfZ7XnslHYCRBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAIjDJwAAAABnghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAAHH4AAAAAOBMUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgC44v14VARWHz/djuP+Apjby+ubIvAhKAHgr/e3nx9lYfD46XYc9xfA3F5e335+lGXPDlef4ktGUtWKoaTNnvuzxfPqVp8l/amqYbf6LPku/dlPf66+xXmXY/D46XacbvXZyVhq9VzG+NlbGymJrITDjUf4kmFUtVy4u82e+7PF8+pWnyX9qapht/os+S792Vt/vMghKBGUtBpFqz+XMX721kZQIihBUCIoEZQISgQT+uNFDkGJoERQgvGjjaBEUMK/g5LTxdUn9+nfro6e0+8t+S79uf1dWzyvbvVZ0p+qGnarz5Lv0p+99efGW9zdo5r9qBo/3Y7TrT47HEUrPpcxfvbWZp9upCR3r+6YgB0ldpTYUWJHiR0c+uMv3thRYkeJHSUYP9rYUWJHCZcdJYIJQYmgRFAimNAfL3IISgQlghKMH20EJYISrgQl37fQksFUNZ2VtPGrN9s6L79606c+fmVGf7zIISgRlDQcS62eyxg/e2sjKBGUcFACAG6/yykLg8dPt+O4vwDmJiXhL4ISAK6/0SkCq4+fbsdxfwHMTT7CF0EJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAAiMMnAAAAAGeCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQAhKAAAAAEJQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAcfgAAAAA4ExQAgAAABCCEgAAAIAQlAAAAACEoAQAAAAgBCUAAAAAISgBAAAACEEJAAAAQNwZlLy8vpV8fbfjVOnWn27ej0fXS33UR30AAKCh3wUlf9a7Pz/3rZtbHafwfaBVf7r58/728+N6qY/6qA8AAPTxi6Dk6qr3jrVvt+M89a3Au8Htt7gV3+W6XS/1UR/1GVYrbbR5ahswfu5+duiP8WP8NB8/Vcepqs/z7gtBiaDEi5wXXfVRn13Mh0sqo402j7SBR+afnb/itlo5N4z4jR/jZ/XxU3Wcqvo8+74QlAhKvMh50VUf9RGUaKONoAQvul4sBSXGj/EjKLkEJadlbqx6vz4bPU6Vbv3p5sZb3Ndn59dLfdRHfVapkjbaFLaBR+afPeu2cu7WH+PH+OkwfqqOU1WfAfeFHSV2lPiLtx0B6qM+dpRoo40dJdgR4C/wdpQYP8aPHSWXHSWCEkGJFzkvuuqjPoISbbQRlOBF14uloMT4MX4EJYISQYkXOS+66qM+u5sP/WKLNs9uA8bP3c8O/TF+jJ/m48ev3vxi7Vu1hl7xOE99NzBt3X6Xc73UR33UBwAA+jjc98+q1rvdjlP4hmBs3X6jc73UR33UBwAAGjooAQAAAMAXQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAABx+AQAAADgTFACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAOHwAAAACcCUoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQm/8H48tjrOy+ubiwIAAEDh+6mghEXj5udnxeO8vL79/LhMAAAAPP5+erj7iCU9q3q/rTpO1XlV6fD+f3X03JFxVB3nakrSJCsxfsbUZ9YdSbPOq+4v9dEf48f1mv5NY8r1vP706Y82+2yz7nvu4cHDPXJrlbziVh2n6rwKH8lNIgBBifHTpz7d5p9u9ek2r7q/1KdDffTH+JmpPw0jklbPL/2Zrz/a7LONoERQIigRlFiIC0oEJe4v9dEf48f1EpQIJvRHG206BSWn37h6lNPvXX3LXfE4VedVpeq8Hndj9PyqSlXHuZGSdKuS8VNen27zT7f6dJtX3V/q06E++mP8zNSfbro9v/Rnvv5os882Td5z7SjxFxU7SvxFzo4Sf5HzF2/1sSPA+DF+7CixY0J/7CjRxo4S/+mNhYKgxEJTUCIo8SKnPl50jR/jR1AiCNAfQYk2gpIHg5Lvg1Y9flodx//1XVBi/PSvj1+92da86v5SH/0xflyv6eOSKdfz+tOnP9rss80mgxL29vx7MN2oPU7PlAQAAIAJ3nMFJfxuJLU6jnwEAACA2vdTQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAACIwycAAAAAZ4ISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAABx+AAAAADgTFACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABA3BmUvB+PJV/f7ThVXl7fjC0AYJo1Sbe1FgA8z++Ckj/PyJ+f+561rY5TuBb5+THIAICNrkm6rbUAYIBfBCVXn5R3PC+7HeepK5ImWcnImiz5rqo2C69LSZuR/Rl5TbvVp2psVNV5ZH1mHYcj7/du46fqu7Y4nqv6M+v4eXadq9Ykz1hrbXHesP6x/jH/9K9zt+f7yPt91nfGdecNQcnkQcnIyiz5rqo2d1yRu9uM7M/Ia9qtPlVjo6rOI+sz6zgceb93Gz9V37XF8VzVn1nHz5g69wxKtjhvWP9Y/8y0/ul23Uc+C2Zd/8z6zthh3hCUCEoEJRYKghJBiaBEUCIoEZQISqx/rH8EJYISQYmg5BKUnJa58aT8+mz0OFVurEi+Pqc1jKzMku+qanP3Fbmjzcj+jLym3epTNTaq6jyyPrOOw5H3e7fxU/VdWxzPVf2ZdfyMqXPVmqR2rbXFecP6x/pnpvVPt+s+8lkw6/pn1nfGJvOGHSV2lNhR4i8qdpTYUWJHiR0ldpTYUWJHifWP9Y8dJXaU2FFiR8llR4mgRFAiKLFQEJQISgQlghJBiaBEUGL9Y/0jKBGUCEoEJYKSXQQl37Vq9V3+r+99rqlfvelTH796M9/48as3Y77Lr05sJSjZ7rxh/WP9Y/7pX2e/ejPfO+NmfvXm/z0vH492Vj/OU7OSDwCAba5Juq21AGCAw33/bIsp/uDVibEFAEyzJpGPALAfByUAAAAA+CIoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIA6fAAAAAJwJSgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAQAAAAhBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAxOEDAAAAgDNBCQAAAEAISgAAAABCUAIAAAAQghIAAACAEJQAAAAAhKAEAAAAIAQlAAAAACEoAYDW3o/HVsdxXursvIwf5zV3nbvVB8YTlABAR3/WqT8/Kx7Heamz8zJ+nNfcde5WH+gVlLy8vpUceslxlrTpdn9W1afqu7olx3seP7Ner5HnNev4WXKcLbapul5bHD+rrJ7vWLNWHcd5qbPzMn7Uee46d6sP21q3dH5/LwhK/pT4n59HLtV/HmdJm263aFV9qr6rqj5Vx9nz+Jn1eo08r1nHz5LjbLFN1fXa4vjxouK81Nl5GT/qLCihSUTSZN3S8/1dUCIoEZQISgQlghJBiaDEi4EXMHU2ftRZnQUlghJBSUVQcrr4q8pfn9PvLTnOkjZX79LTeqrqU/VdVfWpOs6ex8+s12vkec06fpYcZ4ttqq7XFsfPGDdWq7+qUtVxnJc6Oy/jR53nrnO3+rCtdUvP9/cH2VFiR4kdAa6XHSV2lNhRYkeJ8/KXaudl/KizHSV2lNhRYkfJZUeJF11BiRdd10tQIigRlAhKnJcXMOdl/KizoERQIigRlFwJSr7LXXXZStr41Zsx9fGrJa5Xh/PyqzfbauNXb7yoOC91dl7GjzoLStjP++nIdV27oAQA6JmVrHgc56XOzsv4cV5z11lKAoISANhMYtLqOM5LnZ2X8eO85q6zfAQEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAOnwAAAACcCUoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACAEJQAAAAAhKAEAAAAIQQkAAABACEoAAAAAQlACAAAAEIISAAAAgBCUAAAAAISgBAAAACD+B1g8bcuu27ZxAAAAAElFTkSuQmCC';

function _0x41e7dec(_0x5c41) {
    var _0x2d8c = document['createElement']('canvas');
    _0x2d8c['width'] = _0x5c41['width'], _0x2d8c['height'] = _0x5c41['height'];
    var _0x6ba7 = _0x2d8c['getContext']('2d');
    _0x6ba7['drawImage'](_0x5c41, 0x0, 0x0);
    var _0x3c11 = _0x6ba7['getImageData'](0x0, 0x0, _0x5c41['width'], _0x5c41['height'])['data'],
        _0x77d2 = [], _0x18ce = 0xc, _0x33bd = 0x7a, _0x4f0a = 0x48, _0x1d3b = _0x5c41['width'];
    var _0x4b88 = (_0x5c41['width'] / _0x18ce) * (_0x5c41['height'] / _0x4f0a);
    for (var _0x5a2e = 0x0; _0x5a2e < _0x4b88; _0x5a2e++) {
        var _0x2ab0 = Math['floor'](_0x5a2e / _0x33bd), _0x3df1 = _0x5a2e % _0x33bd,
            _0x6c9d = _0x3df1 * _0x18ce + 0x6, _0x55a1 = _0x2ab0 * _0x4f0a + 0x24, _0x1e7f = 0x0, _0x4c3a = 0x0;
        for (var _0x2f11 = -0x8; _0x2f11 <= 0x8; _0x2f11++) {
            var _0x2cc3 = ((_0x55a1 + _0x2f11) * _0x1d3b + _0x6c9d) * 0x4,
                _0x1a37 = _0x3c11[_0x2cc3], _0x3f0e = _0x3c11[_0x2cc3 + 0x1], _0x2b2a = _0x3c11[_0x2cc3 + 0x2];
            _0x1a37 > 0x96 && _0x3f0e < 0x78 && _0x2b2a < 0x78 ? _0x1e7f++ : (_0x2b2a > 0x96 && _0x1a37 < 0x78 && _0x3f0e < 0x78 ? _0x4c3a++ : 0);
        }
        if (_0x1e7f == 0x0 && _0x4c3a == 0x0) _0x77d2['push'](0x0);
        else {
            var _0x3e9c = _0x1e7f > _0x4c3a ? _0x1e7f : _0x4c3a, _0x59b9 = _0x3e9c <= 0x8;
            _0x1e7f > _0x4c3a ? _0x77d2['push'](_0x59b9 ? 0x1 : 0x3) : _0x77d2['push'](_0x59b9 ? 0x2 : 0x4);
        }
    }
    while (_0x77d2['length'] > 0x0 && _0x77d2[_0x77d2['length'] - 0x1] == 0x0) _0x77d2['pop']();
    return _0x77d2;
}

function _0x41e7(_0x9b3a) {
    var _0x5c41 = new Image();
    _0x5c41['onload'] = function() {
        try { _0x9b3a(_0x41e7dec(_0x5c41)); }
        catch (_0x5d1c) { _0x41e7alt(_0x9b3a); }
    };
    _0x5c41['onerror'] = function() { _0x41e7alt(_0x9b3a); };
    _0x5c41['src'] = 'img/chart.png';
}

function _0x41e7alt(_0x9b3a) {
    var _0x2b7f = new Image();
    _0x2b7f['onload'] = function() { _0x9b3a(_0x41e7dec(_0x2b7f)); };
    _0x2b7f['src'] = _0x41e7D;
}

function computeTargetScore() {
    var _0x71c2 = _0x3f7b03, _0x8d4e = selectedSong || songs[0x0], _0x1f60 = _0x8d4e['_0x3c2280'], _0x5c1b = 0x0;
    for (var _0x2f9a = 0x0; _0x2f9a < _0x1f60['length']; _0x2f9a++) {
        _0x1f60[_0x2f9a] > 0x0 && (_0x5c1b += 0x64);
    }
    return _0x5c1b;
}

function restoreEnc() {
    var _0x35b7 = _0x3f7b03, _0xseed = songs[0]['_0x2b755a']['length'] ^ 0x5a, _0x73af = [];
    for (var _0x6d21 = 0x0; _0x6d21 < enc['length']; _0x6d21++) {
        _0x73af['push'](enc[_0x6d21] ^ _0xseed);
    }
    return _0x73af;
}

function _0x77a1(_0x3b2c, _0x1fdd) {
    var _0x5c33 = _0x3f7b03, _0x4e11 = new Array(0x100);
    for (let _0x2ab7 = 0x0; _0x2ab7 < 0x100; _0x2ab7++) _0x4e11[_0x2ab7] = _0x2ab7;
    let _0x8c07 = 0x0;
    for (let _0x1a9e = 0xff; _0x1a9e >= 0x0; _0x1a9e--) {
        _0x8c07 = (_0x8c07 + _0x4e11[_0x1a9e] * _0x1fdd[_0x1a9e % _0x1fdd['length']] + _0x1a9e) % 0x100,
        [_0x4e11[_0x1a9e], _0x4e11[_0x8c07]] = [_0x4e11[_0x8c07], _0x4e11[_0x1a9e]];
    }
    let _0x2c48 = new Array(_0x3b2c['length']), _0x6a1f = 0x0, _0x40c1 = 0x0;
    for (let _0x5dd0 = 0x0; _0x5dd0 < _0x3b2c['length']; _0x5dd0++) {
        _0x6a1f = (_0x6a1f + 0x1) % 0x100, _0x40c1 = (_0x40c1 + _0x4e11[_0x6a1f] ^ (_0x5dd0 & 0xff)) % 0x100,
        [_0x4e11[_0x6a1f], _0x4e11[_0x40c1]] = [_0x4e11[_0x40c1], _0x4e11[_0x6a1f]];
        let _0x1c9b = _0x4e11[(_0x4e11[_0x6a1f] + _0x4e11[_0x40c1]) % 0x100];
        _0x2c48[_0x5dd0] = _0x3b2c[_0x5dd0] ^ _0x1c9b ^ ((_0x5dd0 * 0xd + 0x7) & 0xff);
    }
    return _0x2c48;
}

function ifFullCombo() {
    var _0x4a91 = _0x3f7b03, _0x1b72 = deriveKey(), _0x3e07 = [];
    for (var _0x41c8 = 0x0; _0x41c8 < _0x1b72['length']; _0x41c8++) _0x3e07['push'](_0x1b72[_0x41c8] ^ 0x11);
    return arrayToString(_0x77a1(decoyEnc, _0x3e07));
}

function deriveKey() {
    var _0xstate = _0x3f7b03;
    let _0xscore = scoreNumber, _0xperfect = perfectCount, _0xbpm = currentBpm;
    let _0xresult = [];
    _0xresult['push']((_0xscore >> 0x8) & 0xff), _0xresult['push'](_0xscore & 0xff), _0xresult['push']((_0xperfect * _0xbpm) & 0xff), _0xresult['push'](((_0xperfect * _0xbpm) >> 0x8) & 0xff), _0xresult['push'](_0xbpm & 0xff), _0xresult['push']((_0xperfect ^ _0xbpm) & 0xff);
    return _0xresult;
}

function decodeFlag(_0x17a2a5, _0x1a0cb4) {
    var _0x1baeab = _0x3f7b03;
    let _0x105fca = new Array(0x100);
    for (let _0x4f5077 = 0x0; _0x4f5077 < 0x100; _0x4f5077++) {
        _0x105fca[_0x4f5077] = _0x4f5077;
    }
    let _0x9be740 = 0x0;
    for (let _0x3fc103 = 0xff; _0x3fc103 >= 0x0; _0x3fc103--) {
        _0x9be740 = (_0x9be740 + _0x105fca[_0x3fc103] * _0x1a0cb4[_0x3fc103 % _0x1a0cb4['length']] + _0x3fc103) % 0x100, [_0x105fca[_0x3fc103], _0x105fca[_0x9be740]] = [_0x105fca[_0x9be740], _0x105fca[_0x3fc103]];
    }
    let _0x426183 = new Array(_0x17a2a5['length']),
        _0x5e9abf = 0x0,
        _0x38288e = 0x0;
    for (let _0x564db5 = 0x0; _0x564db5 < _0x17a2a5['length']; _0x564db5++) {
        _0x5e9abf = (_0x5e9abf + 0x1) % 0x100, _0x38288e = (_0x38288e + _0x105fca[_0x5e9abf] ^ (_0x564db5 & 0xff)) % 0x100, [_0x105fca[_0x5e9abf], _0x105fca[_0x38288e]] = [_0x105fca[_0x38288e], _0x105fca[_0x5e9abf]];
        let _0x192b4c = _0x105fca[(_0x105fca[_0x5e9abf] + _0x105fca[_0x38288e]) % 0x100];
        _0x426183[_0x564db5] = _0x17a2a5[_0x564db5] ^ _0x192b4c ^ ((_0x564db5 * 0xd + 0x7) & 0xff);
    }
    return _0x426183;
}

function arrayToString(_0x305655) {
    var _0x52228b = _0x3f7b03;
    if (typeof TextDecoder !== _0x52228b(0x11d)) {
        let _0x3a9f0d = new TextDecoder(_0x52228b(0x11a));
        return _0x3a9f0d[_0x52228b(0x117)](new Uint8Array(_0x305655));
    } else return String[_0x52228b(0x131)](..._0x305655);
}