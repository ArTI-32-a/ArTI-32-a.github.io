"""Public conventions for the case file. Bit 0 is always coordinate 0."""
from hashlib import sha256

DOMAIN = b"casefile/v1"


def coefficient_count(n):
    return 1 + n + n * (n - 1) // 2


def pairs(n):
    return ((i, j) for i in range(n) for j in range(i + 1, n))


def feature(x, n):
    """ANF order: 1, x_0,...,x_(n-1), x_0*x_1, x_0*x_2,... ."""
    out = 1 | (x << 1)
    offset = 1 + n
    for i in range(n - 1):
        if (x >> i) & 1:
            out |= (x >> (i + 1)) << offset
        offset += n - i - 1
    return out


def pack_coefficients(coefficients, n):
    return coefficients.to_bytes((coefficient_count(n) + 7) // 8, "little")


def derive_key(q0, q1, n):
    first, second = sorted([pack_coefficients(q0, n), pack_coefficients(q1, n)])
    return sha256(DOMAIN + b"\0" + n.to_bytes(2, "little")
                  + first + second).digest()
