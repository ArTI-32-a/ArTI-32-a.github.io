from Crypto.Util.number import *
from gmpy2 import next_prime
from math import gcd
from secret import flag

e = 65537
m1 = bytes_to_long(flag[:19])
m2 = bytes_to_long(flag[19:])


p1 = getPrime(512)
q1 = next_prime(p1)
    
n1 = p1 * q1
c1 = pow(m1, e, n1)

while True:
    v = getRandomNBitInteger(256) | 1
    p2 = (3 * v**2 + 1) // 4
    if p2.bit_length() == 512 and isPrime(p2) and gcd(e, p2-1) == 1:
        break

q2 = getPrime(512)
while gcd(e, q2-1) != 1 or q2 == p2:
    q2 = getPrime(512)

n2 = p2 * q2
c2 = pow(m2, e, n2)

print(f'n1 = {n1}')
print(f'c1 = {c1}')
print(f'n2 = {n2}')
print(f'c2 = {c2}')