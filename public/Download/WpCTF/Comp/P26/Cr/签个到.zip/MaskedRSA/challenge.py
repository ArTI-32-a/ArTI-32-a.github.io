from math import gcd
from Crypto.Util.number import bytes_to_long, getPrime
from Crypto.Random.random import randint
from secret import flag
e1 = 65537
e2 = 17
m = bytes_to_long(flag)
while True:
    p = getPrime(512)
    q = getPrime(512)
    phi = (p - 1) * (q - 1)
    if p == q:
        continue
    if gcd(e1, phi) != 1 or gcd(e2, phi) != 1:
        continue
    n = p * q
    if m < n and pow(m, e2) > n and gcd(m, n) == 1:
        break
while True:
    r = randint(2, n - 2)
    if gcd(r, n) == 1:
        break
c1 = pow(m, e1, n)
c2 = pow(m * r % n, e2, n)
c3 = pow(r, e2, n)
print(f"n = {n}")
print(f"e1 = {e1}")
print(f"e2 = {e2}")
print(f"c1 = {c1}")
print(f"c2 = {c2}")
print(f"c3 = {c3}")
