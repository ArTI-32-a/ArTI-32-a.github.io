from hashlib import sha256

MODULUS = 0x11D
DOMAIN = b"nightshift/v1"
EXP = [0] * 510
LOG = [0] * 256
value = 1
for exponent in range(255):
    EXP[exponent] = value
    LOG[value] = exponent
    value <<= 1
    if value & 0x100:
        value ^= MODULUS
for exponent in range(255, 510):
    EXP[exponent] = EXP[exponent - 255]
assert len(set(EXP[:255])) == 255


def mul(a, b):
    return 0 if a == 0 or b == 0 else EXP[LOG[a] + LOG[b]]


def inverse(a):
    if a == 0:
        raise ZeroDivisionError("zero has no multiplicative inverse")
    return EXP[255 - LOG[a]]


def evaluate(coefficients, x):
    value = 0
    for coefficient in reversed(coefficients):
        value = mul(value, x) ^ coefficient
    return value


def derive_key(polynomials):
    serialized = sorted(bytes(polynomial) for polynomial in polynomials)
    return sha256(DOMAIN + b"\0" + b"".join(serialized)).digest()
